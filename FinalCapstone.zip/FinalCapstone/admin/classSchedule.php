<?php
session_start(); // Start the session

$current_page = basename($_SERVER['PHP_SELF']);

// Check if the user is logged in as admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php'); // Redirect to login page if not an admin
    exit();
}

include "../conn.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}



?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Dashboard - NiceAdmin Bootstrap Template</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../NiceAdmin/assets/img/favicon.png" rel="icon">
  <link href="../NiceAdmin/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../NiceAdmin/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../NiceAdmin/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../NiceAdmin/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../NiceAdmin/assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="../NiceAdmin/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="../NiceAdmin/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../NiceAdmin/assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="../NiceAdmin/assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: NiceAdmin
  * Template URL: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/
  * Updated: Apr 20 2024 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

  <?php include "../logo.php"; ?><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-exclamation-circle text-warning"></i>
              <div>
                <h4>Lorem Ipsum</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>30 min. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-x-circle text-danger"></i>
              <div>
                <h4>Atque rerum nesciunt</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>1 hr. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-check-circle text-success"></i>
              <div>
                <h4>Sit rerum fuga</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>2 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-info-circle text-primary"></i>
              <div>
                <h4>Dicta reprehenderit</h4>
                <p>Quae dolorem earum veritatis oditseno</p>
                <p>4 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>
            <li class="dropdown-footer">
              <a href="#">Show all notifications</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-chat-left-text"></i>
            <span class="badge bg-success badge-number">3</span>
          </a><!-- End Messages Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
            <li class="dropdown-header">
              You have 3 new messages
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Maria Hudson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>4 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>Anna Nelson</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>6 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="message-item">
              <a href="#">
                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                <div>
                  <h4>David Muldon</h4>
                  <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                  <p>8 hrs. ago</p>
                </div>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="dropdown-footer">
              <a href="#">Show all messages</a>
            </li>

          </ul><!-- End Messages Dropdown Items -->

        </li><!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <img src="assets/img/profile-img.jpg" alt="Profile" class="rounded-circle">
            <span class="d-none d-md-block dropdown-toggle ps-2">K. Anderson</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6>Kevin Anderson</h6>
              <span>Web Designer</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-person"></i>
                <span>My Profile</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="users-profile.html">
                <i class="bi bi-gear"></i>
                <span>Account Settings</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="pages-faq.html">
                <i class="bi bi-question-circle"></i>
                <span>Need Help?</span>
              </a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="#">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->
  <!-- Sidebar -->
  <?php include '../AdminSide/sidebar.php'; ?>

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section">
      <div class="row">
        <div class="col-lg-12">

          <?php
          // Check if there is a message in the session and display it
          if (isset($_SESSION['message'])) : ?>
            <div class="alert alert-<?= $_SESSION['msg_type'] ?> alert-dismissible fade show" role="alert">
              <i class="bi bi-check-circle me-1"></i>
              <?= $_SESSION['message']; ?>
              <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
          <?php
            // Unset the session variables after displaying the alert
            unset($_SESSION['message']);
            unset($_SESSION['msg_type']);
          endif;
          ?>

          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Subject</h5>
              <!-- Default Tabs -->
              <ul class="nav nav-tabs" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                  <button class="nav-link active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" type="button" role="tab" aria-controls="home" aria-selected="true">Subject</button>
                </li>
                <li class="nav-item" role="presentation">
                  <button class="nav-link" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" type="button" role="tab" aria-controls="profile" aria-selected="false">Time Schedule</button>
                </li>
              </ul>
              <div class="tab-content pt-2" id="myTabContent">
                <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                  <button type="button" class="btn btn-primary rounded-pill btn-sm" data-bs-toggle="modal" data-bs-target="#verticalycentered"> <i class="bi bi-plus"></i>Add Subject</button>
                  <br>
                  <?php
                  // Check if there is a message in the session and display it
                  if (isset($_SESSION['message'])) : ?>
                    <div class="alert alert-<?= $_SESSION['msg_type'] ?> alert-dismissible fade show" role="alert">
                      <i class="bi bi-check-circle me-1"></i>
                      <?= $_SESSION['message']; ?>
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                  <?php
                    // Unset the session variables after displaying the alert
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                  endif;
                  ?>

                  <!-- Start Add Subject Modal-->
                  <div class="modal fade" id="verticalycentered" tabindex="-1" aria-labelledby="addSubjectModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="addSubjectModalLabel">Add Subject</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <!-- SUBJECT FORM -->
                          <form id="addSubjectForm" class="row g-3" method="POST" action="../adminprocess/addSubject.php">
                            <div class="col-md-6">
                              <label for="subjectName" class="form-label">Subject Name</label>
                              <input type="text" class="form-control" id="subjectName" name="subjectName" required>
                            </div>
                            <div class="col-md-6">
                              <label for="subjectCode" class="form-label">Subject Code</label>
                              <input type="text" class="form-control" id="subjectCode" name="subjectCode" required>
                            </div>
                            <div class="mb-3">
                              <label for="teacher" class="form-label">Teacher</label>
                              <input type="text" class="form-control" id="teacher" name="teacher">
                            </div>
                            <div class="mb-3">
                              <label for="Section" class="form-label">Section</label>
                              <input type="text" class="form-control" id="Section" name="Section" placeholder="11 Apollo">
                            </div>
                            <div class="mb-3">
                              <label class="form-label">Meeting Days</label>
                              <div class="row">
                                <div class="col-md-6">
                                  <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="monday" name="meetingDays[]" value="Mon">
                                    <label class="form-check-label" for="monday">Monday</label>
                                  </div>
                                  <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="tuesday" name="meetingDays[]" value="Tues">
                                    <label class="form-check-label" for="tuesday">Tuesday</label>
                                  </div>
                                  <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="wednesday" name="meetingDays[]" value="Wed">
                                    <label class="form-check-label" for="wednesday">Wednesday</label>
                                  </div>
                                </div>
                                <div class="col-md-6">

                                  <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="thursday" name="meetingDays[]" value="Thurs">
                                    <label class="form-check-label" for="thursday">Thursday</label>
                                  </div>
                                  <div class="form-check">
                                    <input class="form-check-input" type="checkbox" id="friday" name="meetingDays[]" value="Fri">
                                    <label class="form-check-label" for="friday">Friday</label>
                                  </div>
                                </div>
                              </div>
                            </div>
                            <div class="mb-3">
                              <label for="semester" class="form-label">Semester</label>
                              <select class="form-select" id="semester" name="semester" required>
                                <option value="" disabled selected>Select Semester</option>
                                <option value="1">1st Semester</option>
                                <option value="2">2nd Semester</option>
                              </select>
                            </div>
                            <div class="mb-3">
                              <label for="year" class="form-label">Academic Year</label>
                              <input type="text" class="form-control" id="year" name="year" required placeholder="e.g., 2024-2025">
                            </div>
                        </div>
                        <div class="modal-footer">
                          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                          <button type="submit" class="btn btn-primary" id="addSubject" name="addSubject">Add Subject</button>
                        </div>
                        </form>
                      </div>
                    </div>
                  </div><!-- End Add Subject Modal-->

                  <!-- Table with stripped rows -->
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Subject Name</th>
                        <th scope="col">Subject Code</th>
                        <th scope="col">Teacher</th>
                        <th scope="col">Section</th>
                        <th scope="col">Meeting Days</th>
                        <th scope="col">Semester</th>
                        <th scope="col">Academic Year</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $sql = "SELECT * FROM subject";
                      $result = $conn->query($sql);
                      $num = 1;
                      if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                          echo "<tr>";
                          echo "<th scope='row'>" . $num . "</th>";
                          echo "<td>" . $row['subject_name'] . "</td>";
                          echo "<td>" . $row['subject_code'] . "</td>";
                          echo "<td>" . $row['teacher'] . "</td>";
                          echo "<td>" . $row['section'] . "</td>";
                          echo "<td>" . $row['meeting_days'] . "</td>";
                          echo "<td>" . ($row['semester'] == 1 ? "1st Semester" : "2nd Semester") . "</td>";
                          echo "<td>" . $row['academic_year'] . "</td>";
                          echo "</tr>";

                          $num++;
                        }
                      } else {
                        echo "<tr><td colspan='8'>No subjects found</td></tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                  <!-- End Table with stripped rows -->
                </div>

                <div class="tab-pane fade" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                  <button type="button" class="btn btn-primary rounded-pill btn-sm" data-bs-toggle="modal" data-bs-target="#addScheduleModal"> <i class="bi bi-plus"></i>Add Schedule</button>
                  <br>
                  <?php
                  // Check if there is a message in the session and display it
                  if (isset($_SESSION['message'])) : ?>
                    <div class="alert alert-<?= $_SESSION['msg_type'] ?> alert-dismissible fade show" role="alert">
                      <i class="bi bi-check-circle me-1"></i>
                      <?= $_SESSION['message']; ?>
                      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    </div>
                  <?php
                    // Unset the session variables after displaying the alert
                    unset($_SESSION['message']);
                    unset($_SESSION['msg_type']);
                  endif;
                  ?>

                  <!-- Start Add Schedule Modal -->
                  <div class="modal fade" id="addScheduleModal" tabindex="-1" aria-labelledby="addScheduleModalLabel" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h5 class="modal-title" id="addScheduleModalLabel">Add Schedule</h5>
                          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                          <!-- SCHEDULE FORM -->
                          <form id="addScheduleForm" class="row g-3" method="POST" action="../adminprocess/createSchedule.php">
                            <select class="form-select" id="subjectName" name="subjectName" required>
                              <option value="" disabled selected>Select Subject</option>
                              <?php
                              // Fetch subjects from the database
                              $sql = "SELECT subject_id, subject_name FROM subject";
                              $result = $conn->query($sql);

                              if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                  echo "<option value='" . $row['subject_name'] . "'>" . $row['subject_name'] . "</option>";
                                }
                              } else {
                                echo "<option value='' disabled>No subjects found</option>";
                              }
                              ?>
                            </select>

                            <div class="col-md-6">
                              <label for="startTime" class="form-label">Start Time</label>
                              <input type="time" class="form-control" id="startTime" name="startTime" required>
                            </div>
                            <div class="col-md-6">
                              <label for="endTime" class="form-label">End Time</label>
                              <input type="time" class="form-control" id="endTime" name="endTime" required>
                            </div>
                            <div class="col-md-12">
                              <label for="classroomLocation" class="form-label">Classroom Location</label>
                              <input type="text" class="form-control" id="classroomLocation" name="classroomLocation" required>
                            </div>
                            <div class="col-md-12">
                              <select class="form-select" id="section" name="section" required>
                                <option value="" disabled selected>Select Section</option>
                                <?php
                                // Fetch distinct sections from the database
                                $sql = "SELECT DISTINCT section FROM subject";
                                $result = $conn->query($sql);

                                if ($result->num_rows > 0) {
                                  while ($row = $result->fetch_assoc()) {
                                    echo "<option value='" . htmlspecialchars($row['section']) . "'>" . htmlspecialchars($row['section']) . "</option>";
                                  }
                                } else {
                                  echo "<option value='' disabled>No sections found</option>";
                                }
                                ?>
                              </select>
                            </div>


                            <div class="modal-footer">
                              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                              <button type="submit" class="btn btn-primary" id="addSchedule" name="addSchedule">Add Schedule</button>
                            </div>
                          </form>
                        </div>
                      </div>
                    </div>
                  </div><!-- End Add Schedule Modal -->

                  <!-- Table with stripped rows -->
                  <table class="table table-striped">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Subject Name</th>
                        <th scope="col">Day</th>
                        <th scope="col">Start Time</th>
                        <th scope="col">End Time</th>
                        <th scope="col">Classroom</th>
                        <th scope="col">Section</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php
                      $sql = "SELECT * FROM classtimeschedule";
                      $result = $conn->query($sql);
                      $num1 = 1;

                      if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                          echo "<tr>";
                          echo "<th scope='row'>" . $num1 . "</th>";
                          echo "<td>" . $row['subject_name'] . "</td>";
                          echo "<td>" . $row['day_of_week'] . "</td>";
                          echo "<td>" . $row['start_time'] . "</td>";
                          echo "<td>" . $row['end_time'] . "</td>";
                          echo "<td>" . $row['classroom_location'] . "</td>";
                          echo "<td>" . $row['section'] . "</td>";
                          echo "</tr>";
                          $num1++;
                        }
                      } else {
                        echo "<tr><td colspan='7'>No schedules found</td></tr>";
                      }
                      ?>
                    </tbody>
                  </table>
                  <!-- End Table with stripped rows -->
                </div>
              </div><!-- End Default Tabs -->

              <div class="col-lg-12">

                <div class="card">
                  <div class="card-body">
                    <h5 class="card-title">Example Card</h5>
                    <!-- Button to trigger Add Shortened Time Modal -->
                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addShortenedTimeModal">
                      Add Shortened Time
                    </button>


                    <!-- Start Add Shortened Time Modal -->
                    <div class="modal fade" id="addShortenedTimeModal" tabindex="-1" aria-labelledby="addShortenedTimeModalLabel" aria-hidden="true">
                      <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                          <div class="modal-header">
                            <h5 class="modal-title" id="addShortenedTimeModalLabel">Add Shortened Time</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <div class="modal-body">
                            <!-- SHORTENED TIME FORM -->
                            <form id="addShortenedTimeForm" class="row g-3" method="POST" action="../adminprocess/createShortenedTime.php">
                              <div class="col-md-6">
                                <label for="shortenedStartTime" class="form-label">Shortened Start Time</label>
                                <input type="time" class="form-control" id="shortenedStartTime" name="shortenedStartTime" required>
                              </div>
                              <div class="col-md-6">
                                <label for="shortenedEndTime" class="form-label">Shortened End Time</label>
                                <input type="time" class="form-control" id="shortenedEndTime" name="shortenedEndTime" required>
                              </div>
                              <div class="col-md-6">
                                <label for="effectiveDate" class="form-label">Effective Date</label>
                                <input type="date" class="form-control" id="effectiveDate" name="effectiveDate" required>
                              </div>
                              <div class="col-md-12">
                                <label for="reason" class="form-label">Reason</label>
                                <textarea class="form-control" id="reason" name="reason" rows="3"></textarea>
                              </div>
                              <div class="col-md-6">
                                <label for="startDate" class="form-label">Start Date</label>
                                <input type="date" class="form-control" id="startDate" name="startDate" required>
                              </div>
                              <div class="col-md-6">
                                <label for="endDate" class="form-label">End Date</label>
                                <input type="date" class="form-control" id="endDate" name="endDate" required>
                              </div>
                              <div class="col-md-12">
                                <label for="subjectName" class="form-label">Subject Name</label>
                                <select class="form-select" id="subjectName" name="subjectName" required>
                                  <option value="" disabled selected>Select Subject</option>
                                  <?php
                                  // Fetch subjects from the database
                                  $sql = "SELECT subject_name FROM subject";
                                  $result = $conn->query($sql);

                                  if ($result->num_rows > 0) {
                                    while ($row = $result->fetch_assoc()) {
                                      echo "<option value='" . $row['subject_name'] . "'>" . $row['subject_name'] . "</option>";
                                    }
                                  } else {
                                    echo "<option value='' disabled>No subjects found</option>";
                                  }
                                  ?>
                                </select>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                <button type="submit" class="btn btn-primary" id="addShortenedTime" name="addShortenedTime">Add Shortened Time</button>
                              </div>
                            </form>
                          </div>
                        </div>
                      </div>
                    </div><!-- End Add Shortened Time Modal -->


                    <!-- Shortened Time Table -->

                    <h2>Shortened Class Times</h2>
                    <!-- Table with stripped rows -->
                    <table class="table table-striped">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Subject Name</th>
                          <th scope="col">Shortened Start Time</th>
                          <th scope="col">Shortened End Time</th>
                          <th scope="col">Effective Date</th>
                          <th scope="col">Reason</th>
                          <th scope="col">Start Date</th>
                          <th scope="col">End Date</th>

                        </tr>
                      </thead>
                      <tbody>
                        <?php
                        $sql = "SELECT * FROM shortenedtime";
                        $result = $conn->query($sql);
                        $num1 = 1;

                        if ($result->num_rows > 0) {
                          while ($row = $result->fetch_assoc()) {
                            echo "<tr>";
                            echo "<th scope='row'>" . $num1 . "</th>";
                            echo "<td>" . $row['subject_name'] . "</td>";
                            echo "<td>" . $row['shortened_start_time'] . "</td>";
                            echo "<td>" . $row['shortened_end_time'] . "</td>";
                            echo "<td>" . $row['effective_date'] . "</td>";
                            echo "<td>" . $row['reason'] . "</td>";
                            echo "<td>" . $row['start_date'] . "</td>";
                            echo "<td>" . $row['end_date'] . "</td>";

                            echo "</tr>";
                            $num1++;
                          }
                        } else {
                          echo "<tr><td colspan='7'>No schedules found</td></tr>";
                        }
                        ?>
                      </tbody>
                    </table>
                    <!-- End Table with stripped rows -->
                  </div>


                </div>
              </div>

            </div>
          </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer" class="footer">
    <div class="copyright">
      &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
    </div>
    <div class="credits">
      <!-- All the links in the footer should remain intact. -->
      <!-- You can delete the links only if you purchased the pro version. -->
      <!-- Licensing information: https://bootstrapmade.com/license/ -->
      <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
      Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="../NiceAdmin/assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="../NiceAdmin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../NiceAdmin/assets/vendor/chart.js/chart.umd.js"></script>
  <script src="../NiceAdmin/assets/vendor/echarts/echarts.min.js"></script>
  <script src="../NiceAdmin/assets/vendor/quill/quill.js"></script>
  <script src="../NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="../NiceAdmin/assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="../NiceAdmin/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../NiceAdmin/assets/js/main.js"></script>

</body>

</html>
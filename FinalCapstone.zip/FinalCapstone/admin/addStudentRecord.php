
<?php
session_start();

// Check if the user is logged in as admin
if (!isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'admin') {
    header('Location: ../index.php'); // Redirect to login page if not an admin
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">

    <title>Dashboard - NiceAdmin Bootstrap Template</title>
    <meta content="" name="description">
    <meta content="" name="keywords">

    <!-- Favicons -->
    <link href="../NiceAdmin/assets/img/favicon.png" rel="icon">
    <link href="../NiceAdmin/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Google Fonts -->
    <link href="https://fonts.gstatic.com" rel="preconnect">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="../NiceAdmin/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/quill/quill.snow.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/quill/quill.bubble.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
    <link href="../NiceAdmin/assets/vendor/simple-datatables/style.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Main CSS File -->
    <link href="../NiceAdmin/assets/css/style.css" rel="stylesheet">

    <script>
        window.onload = function() {
            const urlParams = new URLSearchParams(window.location.search);
            const status = urlParams.get('status');
            const message = urlParams.get('message');
            if (status === 'success') {
                alert('New record created successfully');
            } else if (status === 'error') {
                alert('There was an error creating the record: ' + decodeURIComponent(message));
            } else if (status === 'duplicate') {
                alert('Duplicate record found. Please check the entered details.');
            }

            // Add event listener to gender select to change profile image
            const genderSelect = document.getElementById('inputGender');
            const profileImage = document.getElementById('selectedAvatar');
            genderSelect.addEventListener('change', function() {
                if (genderSelect.value === 'Male') {
                    profileImage.src = '../DefaultProfile/MaleDefaultProfile.png';
                } else if (genderSelect.value === 'Female') {
                    profileImage.src = '../DefaultProfile/FemaleDefaultProfile.png';
                } else {
                    profileImage.src = 'https://mdbootstrap.com/img/Photos/Others/placeholder-avatar.jpg';
                }
            });
        };
    </script>

    <style>
        .table img {
            width: 50px;
            /* Adjust the width as needed */
            height: 50px;
            /* Adjust the height as needed */
            object-fit: cover;
            /* Ensure the image covers the box without stretching */
            border-radius: 50%;
            /* Optional: Make the image circular */
            display: block;
            margin: auto;
            /* Center the image */
        }
    </style>
</head>

<body>

    <!-- ======= Header ======= -->
    <header id="header" class="header fixed-top d-flex align-items-center">

    <?php include "../logo.php"; ?><!-- End Logo -->



        <nav class="header-nav ms-auto">
            <ul class="d-flex align-items-center">

               

                <li class="nav-item dropdown">

                    <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-bell"></i>
                        <span class="badge bg-primary badge-number">4</span>
                    </a><!-- End Notification Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
                        <li class="dropdown-header">
                            You have 4 new notifications
                            <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="notification-item">
                            <i class="bi bi-exclamation-circle text-warning"></i>
                            <div>
                                <h4>Lorem Ipsum</h4>
                                <p>Quae dolorem earum veritatis oditseno</p>
                                <p>30 min. ago</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="notification-item">
                            <i class="bi bi-x-circle text-danger"></i>
                            <div>
                                <h4>Atque rerum nesciunt</h4>
                                <p>Quae dolorem earum veritatis oditseno</p>
                                <p>1 hr. ago</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="notification-item">
                            <i class="bi bi-check-circle text-success"></i>
                            <div>
                                <h4>Sit rerum fuga</h4>
                                <p>Quae dolorem earum veritatis oditseno</p>
                                <p>2 hrs. ago</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="notification-item">
                            <i class="bi bi-info-circle text-primary"></i>
                            <div>
                                <h4>Dicta reprehenderit</h4>
                                <p>Quae dolorem earum veritatis oditseno</p>
                                <p>4 hrs. ago</p>
                            </div>
                        </li>

                        <li>
                            <hr class="dropdown-divider">
                        </li>
                        <li class="dropdown-footer">
                            <a href="#">Show all notifications</a>
                        </li>

                    </ul><!-- End Notification Dropdown Items -->

                </li><!-- End Notification Nav -->

                <li class="nav-item dropdown">

                    <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-chat-left-text"></i>
                        <span class="badge bg-success badge-number">3</span>
                    </a><!-- End Messages Icon -->

                    <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow messages">
                        <li class="dropdown-header">
                            You have 3 new messages
                            <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="message-item">
                            <a href="#">
                                <img src="assets/img/messages-1.jpg" alt="" class="rounded-circle">
                                <div>
                                    <h4>Maria Hudson</h4>
                                    <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                                    <p>4 hrs. ago</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="message-item">
                            <a href="#">
                                <img src="assets/img/messages-2.jpg" alt="" class="rounded-circle">
                                <div>
                                    <h4>Anna Nelson</h4>
                                    <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                                    <p>6 hrs. ago</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="message-item">
                            <a href="#">
                                <img src="assets/img/messages-3.jpg" alt="" class="rounded-circle">
                                <div>
                                    <h4>David Muldon</h4>
                                    <p>Velit asperiores et ducimus soluta repudiandae labore officia est ut...</p>
                                    <p>8 hrs. ago</p>
                                </div>
                            </a>
                        </li>
                        <li>
                            <hr class="dropdown-divider">
                        </li>

                        <li class="dropdown-footer">
                            <a href="#">Show all messages</a>
                        </li>

                    </ul><!-- End Messages Dropdown Items -->

                </li><!-- End Messages Nav -->
<!-- Navbar -->

<?php include '../AdminSide/admin_nav.php';?>

                <!-- End Profile Nav -->

            </ul>
        </nav><!-- End Icons Navigation -->

    </header><!-- End Header -->
    <!-- Sidebar -->
    <?php include '../AdminSide/sidebar.php'; ?>

    <main id="main" class="main">

        <div class="pagetitle">
            <h1>Dashboard</h1>
            <nav>
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                    <li class="breadcrumb-item active">Dashboard</li>
                </ol>
            </nav>
        </div><!-- End Page Title -->

        <section class="section dashboard">
            <div class="row">

                <!-- Left side columns -->
                <div class="col-lg-12">


                    <!-- Student Record-->
                    <div class="col-12">
                        <div class="card  overflow-auto">

                            <div class="card-body">

                                <h5 class="card-title">Student Record</span></h5>
                                <div class="row">
                                    <div class="col-4">
                                        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#largeModal">
                                            <i class="bi bi-plus me-1"></i> Add Student</button>
                                        <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#disablebackdrop ">
                                            <i class="bi bi-file-earmark-spreadsheet me-1"></i> Add Student
                                        </button>

                                    </div>

                                    <table class="table table-border  table-hover">
                                        <thead>
                                            <tr>
                                                <th scope="col">#</th>
                                                <th>Profile</th>
                                                <th scope="col">RFID</th>
                                                <th scope="col">Student ID</th>
                                                <th scope="col">Name</th>
                                                <th scope="col">Birthday</th>

                                                <th scope="col">Section</th>

                                                <th scope="col">Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            include '../conn.php';

                                            // Check connection
                                            if ($conn->connect_error) {
                                                die("Connection failed: " . $conn->connect_error);
                                            }

                                            $sql = $query = "SELECT profile_image_url, first_name, middle_name, last_name, student_id_number, section, rfid_number, date_of_birth FROM students ORDER BY last_name ASC ";

                                            $result = $conn->query($sql);

                                            // Check if query was successful 
                                            if ($result === false) {
                                                echo "Error: " . $conn->error;
                                            } else {
                                                if ($result->num_rows > 0) {
                                                    $count = 1;
                                                    while ($row = $result->fetch_assoc()) {
                                                        echo "<tr>";
                                                        echo "<th scope='row'>" . $count . "</th>";
                                                        echo "<td><img src='" . $row["profile_image_url"] . "' alt='STUDENT PICTURE'></td>";
                                                        echo "<td>" . $row["rfid_number"] . "</td>";
                                                        echo "<td><a href='#'>" . $row["student_id_number"] . "</a></td>";
                                                        echo "<td>" . $row["last_name"] . ", " . $row["first_name"] . " ," . $row["middle_name"] . "</td>";

                                                        echo "<td>" . $row["date_of_birth"] . "</td>";
                                                        echo "<td>" . $row["section"] . "</td>";
                                                        echo "<td><span>";
                                                        echo "<form action='../adminprocess/delete_student.php' method='POST' style='display:inline;' onsubmit='return confirmDelete();'>";
                                                        echo "<input type='hidden' name='rfid_number' value='" . $row["rfid_number"] . "'>";
                                                        echo "<button type='button' class='btn btn-info'><i class='bi bi-info-circle'></i></button>";
                                                        echo "<button type='submit' class='btn btn-danger' onclick='return confirmDelete();'><i class='bi bi-exclamation-octagon'></i></button>";
                                                        echo "</form>";
                                                        echo "</span></td>";
                                                        echo "</tr>";
                                                        $count++;
                                                    }
                                                } else {
                                                    echo "<tr><td colspan='8'>No data found</td></tr>";
                                                }
                                            }

                                            $conn->close();
                                            ?>
                                        </tbody>

                                        <script>
                                            function confirmDelete() {
                                                return confirm("Are you sure you want to delete this student?");
                                            }
                                        </script>


                                    </table>

                                    <!-- Right/End Aligned Pagination -->
                                    <nav aria-label="Page navigation example">
                                        <ul class="pagination justify-content-center">
                                            <li class="page-item disabled">
                                                <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
                                            </li>
                                            <li class="page-item"><a class="page-link" href="#">1</a></li>
                                            <li class="page-item"><a class="page-link" href="#">2</a></li>
                                            <li class="page-item"><a class="page-link" href="#">3</a></li>
                                            <li class="page-item">
                                                <a class="page-link" href="#">Next</a>
                                            </li>
                                        </ul>
                                    </nav><!-- End Right/End Aligned Pagination -->
                                </div>
                            </div>
                        </div><!-- End Student Record -->

                    </div>
                </div><!-- End Left side columns -->


                <!-- Student Personal Record Form -->
                <div class="modal fade" id="largeModal" tabindex="-1">
                    <div class="modal-dialog modal-lg">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Student Personal Record</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div class="modal-body">
                                <div class="card">
                                    <div class="card-body">
                                        <h5 class="card-title">Student Information Form</h5>

                                        <!-- Student Information Form -->
                                        <form class="row g-3" id="studentForm" method="POST" action="../adminprocess/addstudent.php" enctype="multipart/form-data">
                                          
                                            <div class="col-md-4">
                                                <label for="inputFirstName" class="form-label">First Name</label>
                                                <input type="text" class="form-control" id="inputFirstName" name="first_name" placeholder="John" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="inputMiddleName" class="form-label">Middle Name</label>
                                                <input type="text" class="form-control" id="inputMiddleName" name="middle_name" placeholder="Middle">
                                            </div>
                                            <div class="col-md-4">
                                                <label for="inputLastName" class="form-label">Last Name</label>
                                                <input type="text" class="form-control" id="inputLastName" name="last_name" placeholder="Doe" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="inputEmail" class="form-label">Email</label>
                                                <input type="email" class="form-control" id="inputEmail" name="email" placeholder="john.doe@example.com" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="inputStudentIdNumber" class="form-label">Student ID Number</label>
                                                <input type="text" class="form-control" id="inputStudentIdNumber" name="student_id_number" placeholder="11-1111" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="inputDOB" class="form-label">Date of Birth</label>
                                                <input type="date" class="form-control" id="inputDOB" name="date_of_birth" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="inputGender" class="form-label">Gender</label>
                                                <select id="inputGender" class="form-select" name="gender" required>
                                                    <option selected>Choose...</option>
                                                    <option value="Male">Male</option>
                                                    <option value="Female">Female</option>
                                                    <option value="Non-Binary">Non-Binary</option>
                                                    <option value="Prefer not to say">Prefer not to say</option>
                                                </select>
                                            </div>
                                            <div class="col-4">
                                                <label for="inputAddress" class="form-label">Address</label>
                                                <input type="text" class="form-control" id="inputAddress" name="address" placeholder="434 Main St" required>
                                            </div>
                                            <div class="col-md-4">
                                                <label for="inputSection" class="form-label">Section</label>
                                                <select id="inputSection" class="form-select" name="section">
                                                    <option selected>Choose...</option>
                                                    <option value="Section1">Section 1</option>
                                                    <option value="Section2">Section 2</option>
                                                    <option value="Section3">Section 3</option>
                                                </select>
                                            </div>
                                            <div class="col-12">
                                                <label for="rfid_number" class="form-label">RFID Number</label>
                                                <input type="text" class="form-control" id="rfid_number" name="rfid_number" placeholder="0001234" required>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="submit" class="btn btn-primary">Add Student</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div><!-- End Student Personal Record Modal -->
                        </div>
                    </div>
                </div>






                <!-- excel upload modal-->
                <div class="modal fade" id="disablebackdrop" tabindex="-1" data-bs-backdrop="true">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title ">Add Student</h5>
                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <form action="../adminprocess/addstudentexcel.php" method="post" enctype="multipart/form-data">
                                <div class="modal-body">
                                    <label class="form-label" for="customFile">Upload only .xlsx</label>
                                    <input type="file" class="form-control" id="customFile" name="excel" accept=".xls,.xlsx" required />
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                    <button type="submit" class="btn btn-primary" name="import">Upload</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div><!-- End Disabled Backdrop Modal-->


            </div>
        </section>

    </main><!-- End #main -->

    <!-- ======= Footer ======= -->
    <footer id="footer" class="footer">
        <div class="copyright">
            &copy; Copyright <strong><span>NiceAdmin</span></strong>. All Rights Reserved
        </div>
        <div class="credits">
            <!-- All the links in the footer should remain intact. -->
            <!-- You can delete the links only if you purchased the pro version. -->
            <!-- Licensing information: https://bootstrapmade.com/license/ -->
            <!-- Purchase the pro version with working PHP/AJAX contact form: https://bootstrapmade.com/nice-admin-bootstrap-admin-html-template/ -->
            Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
        </div>
    </footer><!-- End Footer -->

    <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="../NiceAdmin/assets/vendor/apexcharts/apexcharts.min.js"></script>
    <script src="../NiceAdmin/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="../NiceAdmin/assets/vendor/chart.js/chart.umd.js"></script>
    <script src="../NiceAdmin/assets/vendor/echarts/echarts.min.js"></script>
    <script src="../NiceAdmin/assets/vendor/quill/quill.js"></script>
    <script src="../NiceAdmin/assets/vendor/simple-datatables/simple-datatables.js"></script>
    <script src="../NiceAdmin/assets/vendor/tinymce/tinymce.min.js"></script>
    <script src="../NiceAdmin/assets/vendor/php-email-form/validate.js"></script>

    <!-- Template Main JS File -->
    <script src="../NiceAdmin/assets/js/main.js"></script>
    <script>
        function displaySelectedImage(event, elementId) {
            const selectedImage = document.getElementById(elementId);
            const fileInput = event.target;

            if (fileInput.files && fileInput.files[0]) {
                const reader = new FileReader();

                reader.onload = function(e) {
                    selectedImage.src = e.target.result;
                };

                reader.readAsDataURL(fileInput.files[0]);
            }
        }
    </script>
    <script>
        <?php
        session_start();
        if (isset($_SESSION['success'])) {
            echo "Swal.fire({
                icon: 'success',
                title: 'Success',
                text: '" . $_SESSION['success'] . "',
            });";
            unset($_SESSION['success']); // Clear the success message
        }
        ?>
    </script>

</body>

</html>
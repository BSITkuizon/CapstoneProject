<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "finalcapstone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the timezone to Philippine Time
date_default_timezone_set('Asia/Manila');

// Get today's date
$currentDate = date('Y-m-d');

// Fetch attendance records for today with student names
$query = "SELECT a.student_id_number, s.first_name, s.last_name, a.date, a.time 
          FROM attendance a
          JOIN students s ON a.student_id_number = s.student_id_number
          WHERE a.date = ?";
$stmt = $conn->prepare($query);

if ($stmt === false) {
    die("Prepare failed: " . $conn->error);
}

$stmt->bind_param("s", $currentDate);
$stmt->execute();
$stmt->bind_result($studentId, $firstName, $lastName, $date, $time);

$attendanceRecords = [];
while ($stmt->fetch()) {
    $attendanceRecords[] = [
        'student_id_number' => $studentId,
        'first_name' => $firstName,
        'last_name' => $lastName,
        'date' => $date,
        'time' => $time
    ];
}

$stmt->close();
$conn->close();

// Return data as JSON
echo json_encode($attendanceRecords);
?>

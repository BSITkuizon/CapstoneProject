<?php
include '../conn.php';

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rfid_number = $_POST['rfid_number'];

    // Prepare and execute SQL query to delete the student
    $sql = "DELETE FROM students WHERE rfid_number = ?";
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("s", $rfid_number);
        if ($stmt->execute()) {
            $message = "Record deleted successfully";
        } else {
            $message = "Error deleting record: " . $stmt->error;
        }
        $stmt->close();
    } else {
        $message = "Error preparing statement: " . $conn->error;
    }
}

$conn->close();

// Redirect back to the referring page with an alert message
$referer = $_SERVER['HTTP_REFERER'];
echo "<script type='text/javascript'>
        alert('$message');
        window.location.href = '$referer';
      </script>";
?>

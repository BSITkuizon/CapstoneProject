<?php
session_start();
include "../conn.php"; // Ensure this file contains your database connection details

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['addShortenedTime'])) {
    $shortenedStartTime = $_POST['shortenedStartTime'];
    $shortenedEndTime = $_POST['shortenedEndTime'];
    $effectiveDate = $_POST['effectiveDate'];
    $reason = $_POST['reason'];
    $startDate = $_POST['startDate'];
    $endDate = $_POST['endDate'];
    $subjectName = $_POST['subjectName'];

    // Prepare SQL statement to insert shortened time
    $sql = "INSERT INTO shortenedTime (shortened_start_time, shortened_end_time, effective_date, reason, start_date, end_date, subject_name)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    // Prepare statement
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    // Bind parameters
    $stmt->bind_param("sssssss", $shortenedStartTime, $shortenedEndTime, $effectiveDate, $reason, $startDate, $endDate, $subjectName);

    // Execute statement
    if ($stmt->execute()) {
        $_SESSION['message'] = "Shortened time added successfully";
        $_SESSION['msg_type'] = "success";
    } else {
        $_SESSION['message'] = "Error: " . $stmt->error;
        $_SESSION['msg_type'] = "danger";
    }

    // Close statement and connection
    $stmt->close();
    $conn->close();

    // Redirect to the form page to show the alert
    header("Location: ../admin/classSchedule.php"); // Adjust the redirect URL as needed
    exit();
}
?>

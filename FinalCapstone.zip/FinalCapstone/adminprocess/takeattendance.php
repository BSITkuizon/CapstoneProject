<?php
$servername = "localhost";
$username = "root"; // Replace with your database username
$password = ""; // Replace with your database password
$dbname = "finalcapstone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $rfid_number = $_POST['rfid'];

    // Retrieve student information based on RFID number
    $sql = "SELECT id, first_name, last_name, student_id_number FROM students WHERE rfid_number = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $rfid_number);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $student = $result->fetch_assoc();
        $student_id = $student['id'];
        $first_name = $student['first_name'];
        $last_name = $student['last_name'];
        $student_id_number = $student['student_id_number'];

        // Insert attendance record
        $sql = "INSERT INTO attendance (student_id, rfid_number) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $student_id, $rfid_number);
        if ($stmt->execute()) {
            echo json_encode([
                "status" => "success",
                "first_name" => $first_name,
                "last_name" => $last_name,
                "student_id_number" => $student_id_number,
                "attendance_time" => date('Y-m-d H:i:s')
            ]);
        } else {
            echo json_encode(["status" => "error", "message" => "Error recording attendance"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "Student not found"]);
    }

    $stmt->close();
}
$conn->close();
?>

<?php
session_start();

include "../conn.php";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

if (isset($_POST['addSubject'])) {
  $subjectName = $_POST['subjectName'];
  $subjectCode = $_POST['subjectCode'];
  $teacher = $_POST['teacher'];
  $section = $_POST['Section'];
  $meetingDays = implode(",", $_POST['meetingDays']);
  $semester = $_POST['semester'];
  $year = $_POST['year'];

  $sql = "INSERT INTO subject (subject_name, subject_code, teacher, section, meeting_days, semester, academic_year)
          VALUES ('$subjectName', '$subjectCode', '$teacher', '$section', '$meetingDays', '$semester', '$year')";

  if ($conn->query($sql) === TRUE) {
    $_SESSION['message'] = "Subject added successfully!";
    $_SESSION['msg_type'] = "success";
  } else {
    // Friendly error messages for non-IT users
    if ($conn->errno == 1062) {
      $_SESSION['message'] = "The subject code or name already exists. Please use a different one.";
    } else if ($conn->errno == 1406) {
      $_SESSION['message'] = "One of the fields contains too many characters. Please shorten your input.";
    } else {
      $_SESSION['message'] = "An error occurred while adding the subject. Please try again.";
    }
    $_SESSION['msg_type'] = "danger";
  }

  $conn->close();

  // Redirect to the form page to show the alert
  header("Location: ../admin/classSchedule.php");
  exit();
}
?>

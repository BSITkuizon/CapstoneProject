<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "finalcapstone";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set the timezone to Philippine Time
date_default_timezone_set('Asia/Manila');

// Initialize variables
$response = [
    'status' => 'error',
    'message' => 'Invalid request',
    'scheduleTimes' => []
];

// Check if subject is set
if (isset($_GET['subject'])) {
    $selectedSubject = $_GET['subject'];
    $currentDateTime = new DateTime();
    $currentDate = $currentDateTime->format('Y-m-d');
    $currentTime = $currentDateTime->format('H:i:s');

    // Fetch the class schedule for the selected subject
    $scheduleStmt = $conn->prepare("
        SELECT sched_id, start_time, end_time
        FROM classtimeschedule
        WHERE subject_name = ? AND day_of_week = DAYNAME(CURDATE())
    ");
    if (!$scheduleStmt) {
        die("Prepare failed: " . $conn->error);
    }

    $scheduleStmt->bind_param("s", $selectedSubject);
    $scheduleStmt->execute();
    $scheduleStmt->store_result();
    $scheduleStmt->bind_result($scheduleId, $startTime, $endTime);

    $validScheduleFound = false;
    $scheduleTimes = []; // Initialize schedule times array

    while ($scheduleStmt->fetch()) {
        $startTimeObj = new DateTime($startTime);
        $endTimeObj = new DateTime($endTime);
        $currentTimeObj = new DateTime($currentTime);

        if ($currentTimeObj >= $startTimeObj && $currentTimeObj <= $endTimeObj) {
            $validScheduleFound = true;

            // Store schedule times for display in 12-hour format
            $scheduleTimes[] = [
                'start_time' => $startTimeObj->format('g:i A'),
                'end_time' => $endTimeObj->format('g:i A')
            ];
        }
    }

    if ($validScheduleFound) {
        $response['status'] = 'success';
        $response['message'] = 'Schedule found';
        $response['scheduleTimes'] = $scheduleTimes;
    } else {
        $response['status'] = 'warning';
        $response['message'] = 'Current time is outside of the scheduled class time';
    }

    $scheduleStmt->close();
}

$conn->close();

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>
